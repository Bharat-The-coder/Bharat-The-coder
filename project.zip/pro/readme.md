**Product entry system **
this project is consist of insertion ,updation,deletion of showing  a data from table "product" named database project
if database not exists 
create database "project"
create table "product" with column

*column*          *datatype* 
id              text
name            text
type            text
quantity        integer 
price           integer
company_name    text
date            date
*or*
~~~run database.py file

